import os
os.system('sh /tmp/exec.sh && rm /tmp/exec.sh')
